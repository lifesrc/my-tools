import Vue from "vue";
function GetDefaultConn(port) {
	if (location.protocol.indexOf('https') > -1)
		return 'wss://wrl.zorrosoft.com:443?sid=' + getrandom(5).toLocaleString() + '&flag=1';
	else
		return 'ws://127.0.0.1:'+port+'?sid=' + getrandom(5).toLocaleString() + '&flag=1';
}
///Vue.prototype.$rules = validate;
// 获取随机数
function getrandom(nums) {
	return ('000000' + Math.floor(Math.random() * 999999)).slice(-6);
}
export default GetDefaultConn;
