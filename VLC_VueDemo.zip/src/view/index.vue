<template>
	<div class="mainContainer">
		<div class="urlbox">
			<div class="item">动态切换</div>
			<div class="item input">
				<el-input v-model="rtsp2" placeholder="这里演示动态切换播放源" size="small"></el-input>
			</div>
			<!-- <div class="item">指定窗口</div> -->
			<div class="item">
				<el-input-number v-model="win" :step="1" size="small" @change="setType()" :min="1"></el-input-number>
			</div>
			<div class="item" style="margin-left: 10px;">
				<el-button type="primary" @click="changUrl()" size="small">切换</el-button>
			</div>
			<!-- <div class="item" style="margin-left: 10px;">
				<el-button @click="init()" size="small" type="danger">链接</el-button>
			</div> -->

		</div>

		<div class="tool">
			<div class="item">窗口宽度</div>
			<div class="item">
				<el-input v-model="width" size="small" class="input" @blur="resize()"></el-input>
			</div>
			<div class="item">窗口高度</div>
			<div class="item">
				<el-input v-model="height" size="small" class="input" @blur="resize()"></el-input>
			</div>
			<div class="item">左边距</div>
			<div class="item">
				<el-input v-model="left" size="small" class="input" @blur="resize()"></el-input>
			</div>
			<div class="item">上边距</div>
			<div class="item">
				<el-input v-model="top" size="small" class="input" @blur="resize()"></el-input>
			</div>
			<div class="item">分屏数量</div>
			<div class="item">
				<el-input-number v-model="ShowType" :step="1" size="small" @change="setType()" :min="1">
				</el-input-number>
			</div>
		</div>
		<div class="tool">
			<div class="item">播放源JSON</div>
			<el-input v-model="WebCfg" size="small"></el-input>
			<div class="item">
				<el-button size="small" @click="RePlay()" type="primary">重新播放</el-button>
			</div>
		</div>
		<!-- <div class="urlbox">
			<div class="item">动态切换</div>
			<div class="item input">
				<el-input v-model="rtsp2" placeholder="这里演示动态切换播放源" size="small"></el-input>
			</div>
			<div class="item">
				<el-button type="primary" @click="changUrl()" size="small">切换</el-button>
			</div>
		</div> -->
		<div class="video-container" ref="player">
			播放器区域
		</div>
		<div class="tool">
			<div class="item">设置字幕</div>
			<div class="item" style="flex: 1;">
				<el-input size="small" placeholder="请输入内容" v-model="danmu.text"></el-input>
			</div>
			<div class="item">
				<el-select size="small" v-model="danmu.position" placeholder="请选择" style="width: 100PX;">
					<el-option label="顶部" value="TOP">
					</el-option>
					<el-option label="底部" value="BOTTOM">
					</el-option>
				</el-select>
			</div>
			<div class="item">位置（x）</div>
			<div class="item">
				<el-input v-model="danmu.x" size="small" class="input"></el-input>
			</div>
			<div class="item">位置（y）</div>
			<div class="item">
				<el-input v-model="danmu.y" size="small" class="input"></el-input>
			</div>
			<div class="item">透明度</div>
			<div class="item">
				<el-input v-model="danmu.opacity" size="small" class="input"></el-input>
			</div>
			<div class="item">大小</div>
			<div class="item">
				<el-input v-model="danmu.size" size="small" class="input"></el-input>
			</div>
			<div class="item">
				<el-button size="small" @click="setText()" type="primary">设置</el-button>
			</div>
		</div>
		<div class="tool">
			<div class="item">选择窗口ID</div>
			<div class="item">
				<el-input-number v-model="win" :step="1" size="small" @change="setType()" :min="1"></el-input-number>
			</div>
			<div class="item">
				<el-button size="small" @click="getCapture">抓图</el-button>
			</div>
			<el-button size="small" @click="watermask">设置水印</el-button>
			<el-button size="small" @click="luxiang">
				<span v-if="isLuxiang">停止录像</span>
				<span v-else>本地录像</span>
			</el-button>
			<el-button size="small" v-if="isSecond" @click="closeOther">
				关闭第二个小程序
			</el-button>
			<el-button size="small" @click="openOther" v-else>
				启动第二个小程序
			</el-button>

			<!-- <el-button size="small" @click="fullscreen">全屏</el-button>
			<el-button size="small" @click="showApp">
				<span v-if="isshow">隐藏</span>
				<span v-else>显示</span>
			</el-button> -->
		</div>
		<div class="tool">
			<div class="item">版本号</div>
			<div class="item">
				<el-input v-model="version" size="small"></el-input>
			</div>
			<el-button size="small" @click="update" type="primary">校验升级</el-button>
		</div>
		<el-input type="textarea" :rows="5" placeholder="发送日志" v-model="log">
		</el-input>
	</div>
</template>

<script>
	//系统关键说明
	//所有发送的msg中用到的rid 可以自己随便指定 不同的发送请求定义唯一的rid 这样可以在回调用轻松判断
	//针对一些特殊请求，可以根据自己的实际情况把rid固定
	//系统首先启动第一个websocket 打开vlc小程序 然后会启动第二个websocket链接 主要用来进行截图、录像等操作
	//窗口id 是固定的参数 从1开始计数 计数顺序为 从左到右，从上到下
	//https://www.videolan.org/
	import GetDefaultConn from "../common/base.js";
	//加载websoket类
	import websocket from '../common/websocket'
	export default {
		components: {

		},
		data() {
			return {
				isdown: false,
				id: 0, //当前vlc小程序ID
				id2: 0, //保存启动的第二个vlc小程序ID
				rid: 0, // 请求序号
				run1:0, // 请求启动播放的序号1
				run2:0, // 请求启动播放的序号2
				win: 1, // 播放实例中当前操作的窗口序号ID
				port: 0, //websocket端口
				rtsp: 'http://www.zorrosoft.com/Files/PluginOKBrowserApplet.mp4',
				rtsp2: 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov',
				isSecond: false,
				width: 1100,
				height: 500,
				left: 0,
				top: 0,
				IframeX: -10,
				IframeY: 0,
				ShowType: 1, //分屏数量
				WebCfg:'[{"ID":2,"Uri":"rtsp://wzh:test123456@192.168.1.8:554/h264/ch1/main/av_stream","Option":":rtsp-tcp"},{"ID":3,"Uri":"http://www.zorrosoft.com/Files/PluginOKBrowserApplet.mp4","Option":":file-caching=300"},{"ID":4,"Uri":"rtsp://wzh:test123456@192.168.1.8:554/h264/ch1/sub/av_stream","Option":":network-caching=200"}]',
				url1:'http://zorrosoft.com/vlcframe.html',
				url2:'http://zorrosoft.com/vlcwebplayer.html',
				result: [], //日志结果数组
				socket: [], //websocket对象数组
				current: 0, //当前用到的websocket对象
				isLuxiang: false, //记录录像的状态
				recordid: 0, //录像时候需要用到的recordid
				isshow: true, //当前小程序是不是隐藏
				danmu: {
					//需要发送的字幕配置信息
					text: '您好呀，O(∩_∩)O哈哈~',
					position: 'TOP',
					color: "#ff0000",
					opacity: 128,
					size: 50,
					x: 0,
					y: 0
				},
				version: '2.2.3.8' //版本信息
			};
		},
		computed: {
			log() {
				return this.result.join("\n")
			},
			clients() {
				//获取当前客户端总数
				return this.socket.length
			}
		},
		mounted() {
			//初始化配置
			this.init()

		},
		beforeDestroy() {
			//关闭所有websocket链接以及浏览器监听
			this.close()

		},
		methods: {
			init() {
				//监听浏览器切换标签页面
				document.addEventListener('visibilitychange', this.handleVisiable)
				//侦听滚动条
				window.addEventListener('scroll', this.windowScroll)
				//监听当页面离开时候
				window.addEventListener('unload', this.unloadHandler)
				//获取播放器位置节点信息
				this.getPlayerPosition()

			},
			windowScroll() {
				// 滚动条距离页面顶部的距离
				let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
				console.log(scrollTop);
				this.appScroll(0, this.id, scrollTop)
				if (this.id2 > 0) {
					this.appScroll(2, this.id2, scrollTop)
				}

			},
			appScroll(current, id, scrollTop) {
				//滚动小程序实例
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_AppletScroll",
					"rid": this.rid,
					"para": {
						"ID": id,
						"Code": 2,
						"Left": 0,
						"Top": scrollTop
					}
				}
				if(id)
					this.socket[current].sendObj(msg)
			},
			getPlayerPosition() {
				//获取播放器位置节点信息 
				let react = this.$refs.player.getBoundingClientRect()
				this.left = Math.round(react.left)
				this.top = Math.round(react.top)
				//启动的小程序
				this.opend()
			},
			handleVisiable(e) {
				//浏览器页面切换侦听回调函数
				if (e.target.visibilityState == 'hidden') {
					//切离该页面时执行
					console.log('lever')
					this.hideApp()
				} else if (e.target.visibilityState == 'visible') {
					//切换到该页面时执行
					console.log('enter')
					this.showApp()
				}
			},
			unloadHandler() {
				//关闭所有websoket链接
				this.close()
			},
			close() {
				//关闭所有websoket链接
				console.log(this.socket)
				this.socket.forEach((item) => {
					item.disconnect()
				})
				this.socket = []
				//关闭侦听浏览器页面切换
				document.removeEventListener('visibilitychange', this.handleVisiable)
				//关闭侦听滚动条
				window.removeEventListener('scroll', this.windowScroll)
				//关闭侦听滚动条
				window.removeEventListener('unload', this.unloadHandler)
			},
			opend() {
				//打开vlc小程序，这是旧方法，启动播放推荐用RePlay中的方法，不需要Url参数了
				this.rid++;/// 增加序号
				this.openWebsocket(83)
				let msg = {
					"req": "Wrl_VLCApplet",
					"rid": this.rid,
					"para": {
						"Type": "0",
						"Title": "VLC多媒体播放小程序",
						"Flag": 2,
						"Left": this.left,
						"Top": this.top,
						"Width": this.width,
						"Height": this.height,
						"IframeX": this.IframeX,
						"IframeY": this.IframeY,
						"BarW": 0,
						"BarH": 0,
						"ScrollTop": 0,
						"Url": this.url1,
						"ShowType": this.ShowType,
						"Open": this.rtsp
					}
				}
				this.socket[0].sendObj(msg)
			},
			openOther() {
				//改变第一个小程序位置
				this.width = 550
				this.resize()
				//演示打开第二个vlc小程序
				//打开vlc小程序，这是旧方法，启动播放推荐用RePlay中的方法，不需要Url参数了
				this.openWebsocket(83)
				this.current = 2
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_VLCWebPlayer",
					"rid": this.rid,
					"para": {
						"Type": "0",
						"Title": "VLC Web Player",
						"Flag": 514,
						"Left": this.left + 550,
						"Top": this.top,
						"Width": 550,
						"Height": 500,
						"IframeX": -10,
						"IframeY": 0,
						"BarW": 0,
						"BarH": 0,
						"ScrollTop": 0,
						"Url": this.url2,
						"ShowType": this.ShowType,
						"Open": this.rtsp
					}
				}
				this.socket[this.current].sendObj(msg)
				this.isSecond = true
			},
			closeOther() {
				if (this.isSecond) {
					this.socket[2].disconnect()
					this.socket[3].disconnect()
					this.socket.splice(2, 2)
					this.isSecond = false
					this.id2 = 0
					//还原第一个小程序位置
					this.width = 1100
					this.height = 500
					//获取播放器位置节点信息
					let react = this.$refs.player.getBoundingClientRect()
					this.left = react.left
					this.top = react.top
					this.resize()
					
				}
			},
			RePlay()
			{
				if (this.id > 0) 
				{
					this.rid++;/// 增加序号
					let msg = {
						"req": "Wrl_AppletControl",
						"rid": this.rid,
						"para": {
							"ID": this.id,
							"Code": 1
						}
					}
					this.socket[0].sendObj(msg)
				}
				this.id = 0
				this.current = 0
				this.rid++;/// 增加序号
				//重新初始化播放，采用不需要Url参数的方式,Flag+64，Web配置播放源，设置分屏风格4
				this.ShowType = 4
				let Msg = {
					"req": "Wrl_VLCApplet",
					"rid": this.rid,
					"para": {
						"Type": "0",
						"Title": "VLC多媒体播放小程序",
						"Flag": 66,
						"Left": this.left,
						"Top": this.top,
						"Width": this.width,
						"Height": this.height,
						"IframeX": this.IframeX,
						"IframeY": this.IframeY,
						"BarW": 0,
						"BarH": 0,
						"ScrollTop": 0,
						"Web": JSON.parse(this.WebCfg),
						"ShowType": this.ShowType
					}
				}
				this.socket[0].sendObj(Msg)
			},
			openWebsocket(port) {
				//打开websocket服务
				let ws = GetDefaultConn(port);
				const socketClient = new websocket(ws, {
					reconnectEnabled: false
				})
				socketClient.connect()
				this.socket.push(socketClient)
				socketClient.onMessage = (msg) => 
				{
					console.log(JSON.parse(msg.data))
					let res = JSON.parse(msg.data)
					if(res.req == 'Wrl_VLCApplet'){
						this.run1 = res.rid
					}
					if(res.req == 'Wrl_VLCWebPlayer'){
						this.run2 = res.rid
					}
					if (res.event == 'Wrl_AppletOK') {
						//小程序创建成功后台 获取当前小程序id
						if (res.rid == this.run1) {
							this.id = res.aid
							console.log(this.id)
						}
						if (res.rid == this.run2) {
							this.id2 = res.aid
							console.log(this.id2)
						}
					}
					if (res.event == 'Wrl_Listen') {
						this.port = res.data.port
						//小程序创建成功后台 获取当前小程序返回的端口 
						//这里开通另外一个websocket 来实现重新指定播放源，暂停播放，抓图等
						this.openWebsocket(this.port)
					}
					//切换窗口的时候 设定当前窗口为此窗口
					if (res.event == 'VLC_Selected') {
						this.win = res.ID
					}
					//侦听录像的rid
					if (res.rid == 9000) {
						//记录录像的pid
						this.recordid = res.data.PID
					}
					if (res.rid == 9001) {
						this.$message.success("录像成功\n" + res.data.File);
						//console.log(res.data.Img[0].File)
					}
					if (res.rid == 9002) {
						this.$message.success("截图成功\n" + res.data.Img[0].File);
						//console.log(res.data.Img[0].File)
					}
					if (res.rid == 9999) 
					{
						if (res.data.Update == 1) {
							this.$confirm('有新版本发布, 是否升级?', '提示', {
								confirmButtonText: '确定',
								cancelButtonText: '取消',
								type: 'warning'
							}).then(() => {
								this.getUpdateJson()
							}).catch(() => {

							});
						} else {
							this.$message.success('暂无新版本');
						}
					}
					//记录日志
					this.result.push(msg.data)
				}
				socketClient.onClose = (msg) => {
					console.log(msg)
					console.log('socket closed')
				}
				socketClient.onError = (msg) => {
					console.log('socket error')
					//连接不上，认为还没有安装VLC网页播放程序 没有安装时提示安装
					this.$confirm('VLC网页播放程序 尚未安装，是否马上下载？', '提示', {
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						type: 'warning'
					}).then(() => {
						window.open('http://zorrosoft.com/Files/RtspWebPlayerIns.exe')
					}).catch(() => {

					});
				}
			},
			resize() {
				//请求改变VLC多媒体播放网页小程序显示位置或大小
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_AppletResize",
					"rid": this.rid,
					"para": {
						"ID": this.id,
						"Width": this.width,
						"Height": this.height,
						"X": this.left,
						"Y": this.top
					}
				}
				this.socket[0].sendObj(msg)
			},
			getCapture() {
				//请求截图，固定请求ID处理，也可以是建立一个map记录每个rid对应的含义，请求返回里再处理
				let msg = {
					"req": "VLC_VideoSnapshot",
					"rid": 9002,
					"para": [{
						"ID": this.win,
						"Type": 4,
						"Count": 1,
						"Delay": 1000,
						"Interval": 200,
						"PathType": 1
					}]
				}
				this.socket[1].sendObj(msg)
			},
			setText() {
				//发送字幕到指定的窗口ID
				this.rid++;/// 增加序号
				let msg = {
					"req": "VLC_MarqueePut",
					"rid": this.rid,
					"para": [{
						"ID": this.win,
						"Text": this.danmu.text,
						"Position": this.danmu.position,
						"Timeout": 0,
						"Color": this.danmu.color,
						"Opacity": this.danmu.opacity,
						"Refresh": 1,
						"Size": this.danmu.size,
						"X": this.danmu.x,
						"Y": this.danmu.y
					}]
				}
				this.socket[1].sendObj(msg)
			},
			setType() {
				//动态改变屏幕数量
				this.rid++;/// 增加序号
				let msg = {
					"req": "VLC_ChangePlay",
					"rid": this.rid,
					"para": {
						"ShowType": this.ShowType
					}
				}

				this.socket[1].sendObj(msg)
			},
			fullscreen() {
				//全屏
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_AppletControl",
					"rid": this.rid,
					"para": {
						"ID": this.id,
						"Code": 2
					}
				}
				this.socket[0].sendObj(msg)
			},
			luxiang() {
				//对指定的窗口ID进行录像 固定请求ID处理，也可以是建立一个map记录每个rid对应的含义，请求返回里再处理
				let msg = {}
				if (this.isLuxiang) {
					msg = {
						"req": "VLC_StopRecord",
						"rid": 9001,
						"para": {
							"PID": this.recordid
						}
					}
					this.isLuxiang = false
				} else {
					msg = {
						"req": "VLC_RecordFile",
						"rid": 9000,
						"para": {
							//不指定Url时取当前焦点分屏窗口源进行录像
							//"Url": this.rtsp,
							"File": "C:/Zorro/test.mp4",
							"Second": 30
						}
					}
					this.isLuxiang = true
				}

				this.socket[1].sendObj(msg)
			},
			watermask() {
				//对指定的窗口ID发送水印
				this.rid++;/// 增加序号
				let msg = {
					"req": "VLC_PutLogoShow",
					"rid": this.rid,
					"para": [{
						"ID": this.win,
						"File": "VLC.png",
						"Delay": 20,
						"Repeat": -1,
						"Opacity": 128,
						"X": 100,
						"Y": 100
					}]
				}
				this.socket[1].sendObj(msg)
			},
			changUrl() {
				//动态改变指定的窗口ID的播放源
				this.rid++;/// 增加序号
				let msg = {
					"req": "VLC_ChangePlay",
					"rid": this.rid,
					"para": {
						"Play": [{
							"ID": this.win,
							"Uri": this.rtsp2,
							"Name": "BrowserApplet1",
							"Option": ":rtsp-tcp"
						}]
					}
				}
				this.socket[1].sendObj(msg)
			},
			showApp() {
				//显示VLC小程序
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_AppletControl",
					"rid": this.rid,
					"para": {
						"ID": this.id,
						"Code": 8
					}
				}
				if (this.id > 0) {
					this.socket[0].sendObj(msg)
				}
				//如果启动了第二个小程序 也把他隐显示
				if (this.id2 > 0) {
					msg.para.ID = this.id2
					this.socket[2].sendObj(msg)
				}
			},
			hideApp() {
				//隐藏VLC小程序
				this.rid++;/// 增加序号
				let msg = {
					"req": "Wrl_AppletControl",
					"rid": this.rid,
					"para": {
						"ID": this.id,
						"Code": 4
					}
				}
				if (this.id > 0) {
					this.socket[0].sendObj(msg)
				}
				//如果启动了第二个小程序 也把他显示
				if (this.id2 > 0) 
				{
					this.rid++;/// 增加序号
					msg.rid = this.rid
					msg.para.ID = this.id2
					this.socket[2].sendObj(msg)
				}
			},
			update() {
				//校验中间件版本是不是需要升级,如果额外指定PID参数，代表校验PID代表的小程序，Wrl_Version功能多，指定特定的rid来判断
				let msg = {
					"req": "Wrl_Version",
					"rid": 9999,
					"para": {
						"Version": this.version
					}
				}
				this.socket[0].sendObj(msg)
			},
			getUpdateJson() {
				//发送中间件的升级命令，实现系统自动升级，同时升级VLC网页播放小程序
				this.rid++;/// 增加序号
				let msg = {
					"req":"Wrl_Update",
					"rid":this.rid,
					"para":{
						"Name":"RTSP流播放小程序升级包",
						"Date":"2021-12-16",
						"Desc":"1、海康网页播放小程序增加LibVLC引擎播放网络视频文件和视频流，支持播放多种事件通知；2、优化RTSP流网页播放小程序对XP系统的兼容性，解决关闭播放可能崩溃问题；3、优化RTSP流网页播放小程序双击全屏处理逻辑及播放状态显示的效果；4、优化RTSP流网页播放小程序播放进度通知、抓图返回Base64数据性能和及自动删除临时文件功能",
						"DownAddr":"http://local.zorrosoft.com/Files/Update/RTSP_Update.pid",
						"MD5":"1AEFE3563055A7A7BC20D783C604C329",
						"Version":"2.2.3.8",
						"Size":15532032,
						"HideIns":0,
						"Cookie":"",
						"Auth":"",
						"TK":"324E5884B2AF57A6557F96919657064333091A184E91ED3A6BD2F58A8710BD8054E33B1B337F207C1ED45FAB91ACBB443E6F3E400CC40C045CD237073EF0E9CBE575C8D995F7B30CF877E6C8F94AAD43447202277B160C8453AB9325F39F7C2F43FFB9E2BE16C24EC79A51885FCAC10B1620CBBC67A3E204D328BDF790407A7E1FCFFB9FBC42F90898BB73F8DAC6B62A4A8007396792B9767BD1E803166A4F07C1995010738211BCF0D34E4B2D1E51FC64F6C03C13DC6B70A76AF0EAA1918D3454CC2FD7DE739D13E940828A657213A4EA39BC83311B267AD13E4160F67396B8F382FB70DFA175D4CDDFB5F052F537E4F7B574B7F00AC67880A0A215A3BA3FAC"
					}
				}
				this.socket[0].sendObj(msg)
			}
		}
	};
</script>

<style scoped>
	.mainContainer {
		display: block;
		width: 1100px;
		margin-left: auto;
		margin-right: auto;
		box-sizing: border-box;
	}

	.urlbox {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin: 15px 0;
	}

	.urlbox .input {
		flex: 1;
		margin: 0 15px;
	}

	.tool {
		display: flex;
		align-items: center;
		margin: 15px 0;
	}

	.tool .item {
		margin-right: 15px;
	}

	.tool .item:last-child {
		margin-right: 0;
	}

	.tool .input {
		width: 60px;
	}

	.video-container {
		position: relative;
		margin-top: 8px;
		height: 500px;
		border: #ddd 1px dashed;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 24px;
		color: #ddd;
	}
</style>
